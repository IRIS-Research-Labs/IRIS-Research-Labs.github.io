Zempekotetris v1.0
 by Harry Kakoulidis 12/1999

www.xarka.com
freeware@xarka.com

It took me two whole houres to code this game. So please enjoy it!
I got the idea when I wanted to test some mp3's routines.


This uses two excelent components that I found:

*  TKozyTetris component by Gasper Kozak.
   E-mail: gasper.kozak@email.si (home), gasper@hsp.si (work)

*  EldoS Sounds by Eugene Mayevski.

